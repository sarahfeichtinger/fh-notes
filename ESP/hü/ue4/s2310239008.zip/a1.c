#include <stdio.h>

/**
 * Initializes an array representing 100 prison cells, where each cell is initially closed (0).
 * It then performs a simulation of the king's amnesty process,
 * where specific cells are opened or closed based on a series of instructions.
 * After the simulation, the program prints the numbers of the cells that are now open,
 * indicating the prisoners who have been granted amnesty.
 *
 * @return 0 if the code runs without errors
 */
int main(void)
{

    int doors[100] = { 0 };
    int firstDoorPrinted = 0;

    // needed, because the iteration over the 100 doors in the inner for-loop happens a 100 times (100 rounds)
    for (int i = 0; i < 100; i++) {

        /**
        * simulates the king's amnesty process
        * starting with the cell door of each rounds number, so in the first round with the first door, in the second with the second,..
        * step size is also the number of the current round, plus 1 because the outer for loop starts at 0 not 1
        * toggels the doors to 0 if 1 and 1 if 0
        */
        for (int j = i; j < 100; j = j + i + 1) {
            doors[j] = !(doors[j]);
        }
    }

    printf("Open doors: ");

    // Loop through the doors array to print the open doors
    for (int i = 1; i <= 100; i++) {

        // Check if the door is open
        // i-1 because arrays start at 0
        if (doors[i - 1]) {

            // Format the comma in the output by handling the first printed door separately
            if (!firstDoorPrinted) {
                printf("%d", i);
                firstDoorPrinted = 1;
            }
            else {
                printf(", %d", i);
            }
        }
    }

}